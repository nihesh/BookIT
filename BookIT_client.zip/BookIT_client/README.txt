------------------------------------------------------------------------------------------------------------

										BOOKIT Client Application

------------------------------------------------------------------------------------------------------------

Setup procedure for linux systems

Option - 1

-> While setting up for the first time, the following command needs to be executed

./BookIT.sh  <ServerIP>  <ServerPort> (or) sh BookIT.sh  <ServerIP>  <ServerPort>  

-> Once server IP and port are set-up, the app can be executed normally using ./BookIT.sh (or) sh BookIT.sh

Option - 2

ServerInfo.txt has to be manually configured to mention server IP and port. This is a one time procedure

File format:
<ServerIP>
<ServerPort> 

A sample has been mentioned in the file

Once the setup is done, the jar file can be executed directly using Java 1.8+

--------------------------------------------------------------------------------------------------------------

Developed by
Nihesh Anderson
Harsh Pathak